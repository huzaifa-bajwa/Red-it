import './App.css';
import LoginSignup from './components/loginSignup';

function App() {
  return (
    <div>
      <LoginSignup />
    </div>
  );
}

export default App;
